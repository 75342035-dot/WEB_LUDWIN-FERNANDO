require('dotenv').config();
const path = require('path');
const fs = require('fs');
const express = require('express');
const cors = require('cors');
const ExcelJS = require('exceljs');
const nodemailer = require('nodemailer');

const app = express();
const PORT = process.env.PORT || 3000;
const DATA_DIR = path.join(__dirname, 'data');
const EXCEL_PATH = path.join(DATA_DIR, 'registros.xlsx');
if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR);

app.use(cors());
app.use(express.json());
app.use(express.static(__dirname)); // sirve la web (index.html, registrar-cv.html, ...)

const COLUMNAS = [
  { header: 'Fecha de registro',    key: 'fecha_registro',       width: 20 },
  { header: 'Nombres',              key: 'nombres',              width: 22 },
  { header: 'Apellidos',            key: 'apellidos',            width: 24 },
  { header: 'Código universitario', key: 'codigo_universitario', width: 22 },
  { header: 'Correo electrónico',   key: 'email',                width: 30 },
  { header: 'Número de celular',    key: 'telefono',             width: 18 },
  { header: 'Semestre académico',   key: 'semestre',             width: 18 },
  { header: 'Área de interés',      key: 'area_interes',         width: 20 },
  { header: 'Fecha de nacimiento',  key: 'fecha_nacimiento',     width: 20 },
  { header: 'Lugar de nacimiento',  key: 'lugar_nacimiento',     width: 24 },
  { header: 'Estado civil',         key: 'estado_civil',         width: 16 },
  { header: 'Nacionalidad',         key: 'nacionalidad',         width: 16 },
  { header: 'DNI',                  key: 'dni',                  width: 14 },
  { header: 'Ubicación',            key: 'ubicacion',            width: 20 },
  { header: 'Rubro',                key: 'rubro',                width: 18 },
  { header: 'Especialidad',         key: 'especialidad',         width: 24 },
  { header: 'Años de experiencia',  key: 'experiencia_anos',     width: 18 },
  { header: 'Nivel de estudios',    key: 'nivel_estudios',       width: 20 },
  { header: 'Certificaciones',      key: 'certificaciones',      width: 36 },
  { header: 'Habilidades',          key: 'habilidades',          width: 36 },
  { header: 'Sobre mí',             key: 'sobre_mi',             width: 50 }
];

// Abre registros.xlsx (o lo crea) y agrega una fila
async function agregarRegistro(d) {
  const wb = new ExcelJS.Workbook();
  let ws;
  if (fs.existsSync(EXCEL_PATH)) {
    await wb.xlsx.readFile(EXCEL_PATH);
    ws = wb.getWorksheet('Registros');
  }
  if (!ws) {
    ws = wb.addWorksheet('Registros');
    ws.columns = COLUMNAS;
    const h = ws.getRow(1);
    h.font = { bold: true, color: { argb: 'FFFFFFFF' } };
    h.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FF1F3A5F' } };
    h.alignment = { vertical: 'middle', horizontal: 'center' };
    ws.views = [{ state: 'frozen', ySplit: 1 }];
  } else {
    ws.columns = COLUMNAS; // restaura las claves al reabrir
  }
  ws.addRow(d);
  await wb.xlsx.writeFile(EXCEL_PATH);
  return EXCEL_PATH;
}

const limpiar = v => String(v ?? '').trim().slice(0, 200);

app.post('/api/registro', async (req, res) => {
  try {
    const b = req.body || {};
    const d = { fecha_registro: new Date().toLocaleString('es-PE', { timeZone: 'America/Lima' }) };
    for (const c of COLUMNAS) if (c.key !== 'fecha_registro') d[c.key] = limpiar(b[c.key]);
    d.certificaciones = String(b.certificaciones ?? '').trim().slice(0, 1000);
    d.habilidades = String(b.habilidades ?? '').trim().slice(0, 1000);
    d.sobre_mi = String(b.sobre_mi ?? '').trim().slice(0, 2000);

    const obligatorios = ['nombres', 'apellidos', 'email', 'area_interes',
      'fecha_nacimiento', 'lugar_nacimiento', 'estado_civil', 'nacionalidad'];
    const falta = obligatorios.filter(k => !d[k]);
    if (falta.length) return res.status(400).json({ error: 'Faltan campos: ' + falta.join(', ') });
    if (!/^\S+@\S+\.\S+$/.test(d.email)) return res.status(400).json({ error: 'Correo inválido' });

    const archivo = await agregarRegistro(d);

    if (process.env.DRY_RUN === '1') {
      console.log('[DRY_RUN] Registro guardado, no se envió correo:', d.email);
      return res.json({ ok: true, dryRun: true });
    }

    const { EMAIL_USER, EMAIL_PASS } = process.env;
    const EMAIL_DESTINO = process.env.EMAIL_DESTINO || 'ludwinfturpo09@gmail.com'; // dueño de la web
    if (!EMAIL_USER || !EMAIL_PASS) {
      return res.status(500).json({ error: 'Falta configurar el archivo .env (EMAIL_USER, EMAIL_PASS)' });
    }

    const transporter = nodemailer.createTransport({
      service: 'gmail',
      auth: { user: EMAIL_USER, pass: EMAIL_PASS.replace(/\s/g, '') }
    });

    await transporter.sendMail({
      from: `"LUDSTORE" <${EMAIL_USER}>`,
      to: EMAIL_DESTINO,
      subject: `Nuevo registro: ${d.nombres} ${d.apellidos}`,
      text:
`Se registró una nueva persona en LUDSTORE.
Total de participantes registrados: ver el Excel adjunto.

Nombres y apellidos: ${d.nombres} ${d.apellidos}
Código universitario: ${d.codigo_universitario || '-'}
Correo: ${d.email}
Celular: ${d.telefono}
Semestre: ${d.semestre || '-'}
Área de interés: ${d.area_interes}

Adjunto el Excel con todos los registros acumulados.`,
      attachments: [{ filename: 'registros_ludstore.xlsx', path: archivo }]
    });

    res.json({ ok: true });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'No se pudo procesar el registro: ' + err.message });
  }
});

app.listen(PORT, () => console.log(`LUDSTORE en http://localhost:${PORT}`));
