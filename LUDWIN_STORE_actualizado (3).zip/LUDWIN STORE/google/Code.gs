// LUDSTORE - Recibe los registros, los guarda en la hoja y envía el Excel al dueño.
const DESTINO = 'ludwinfturpo09@gmail.com';

const COLUMNAS = [
  ['Fecha de registro', 'fecha_registro'],
  ['Nombres', 'nombres'],
  ['Apellidos', 'apellidos'],
  ['Código universitario', 'codigo_universitario'],
  ['Correo electrónico', 'email'],
  ['Número de celular', 'telefono'],
  ['Semestre académico', 'semestre'],
  ['Área de interés', 'area_interes'],
  ['Fecha de nacimiento', 'fecha_nacimiento'],
  ['Lugar de nacimiento', 'lugar_nacimiento'],
  ['Estado civil', 'estado_civil'],
  ['Nacionalidad', 'nacionalidad'],
  ['DNI', 'dni'],
  ['Ubicación', 'ubicacion'],
  ['Rubro', 'rubro'],
  ['Especialidad', 'especialidad'],
  ['Años de experiencia', 'experiencia_anos'],
  ['Nivel de estudios', 'nivel_estudios'],
  ['Certificaciones', 'certificaciones'],
  ['Habilidades', 'habilidades'],
  ['Sobre mí', 'sobre_mi']
];

function doPost(e) {
  const p = e.parameter || {};
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  let sh = ss.getSheetByName('Registros') || ss.insertSheet('Registros');

  if (sh.getLastRow() === 0) {
    sh.getRange(1, 1, 1, COLUMNAS.length).setValues([COLUMNAS.map(c => c[0])])
      .setFontWeight('bold').setBackground('#1F3A5F').setFontColor('#FFFFFF');
    sh.setFrozenRows(1);
  }

  const fila = COLUMNAS.map(c => c[1] === 'fecha_registro'
    ? Utilities.formatDate(new Date(), 'America/Lima', 'dd/MM/yyyy HH:mm')
    : String(p[c[1]] || ''));
  // formato texto para que "+51 999..." o códigos no se conviertan en fórmulas
  sh.getRange(sh.getLastRow() + 1, 1, 1, fila.length).setNumberFormat('@').setValues([fila]);
  SpreadsheetApp.flush();

  // Enviar el Excel con TODOS los registrados al dueño
  try {
    const url = 'https://docs.google.com/spreadsheets/d/' + ss.getId() + '/export?format=xlsx';
    const blob = UrlFetchApp.fetch(url, {
      headers: { Authorization: 'Bearer ' + ScriptApp.getOAuthToken() }
    }).getBlob().setName('registros_ludstore.xlsx');

    MailApp.sendEmail({
      to: DESTINO,
      subject: 'Nuevo registro: ' + (p.nombres || '') + ' ' + (p.apellidos || ''),
      body: 'Se registró una nueva persona en LUDSTORE.\n\n' +
            'Nombre: ' + (p.nombres || '') + ' ' + (p.apellidos || '') + '\n' +
            'Correo: ' + (p.email || '') + '\n' +
            'Celular: ' + (p.telefono || '') + '\n' +
            'Código universitario: ' + (p.codigo_universitario || '-') + '\n' +
            'Área de interés: ' + (p.area_interes || '') + '\n\n' +
            'Total de registrados: ' + (sh.getLastRow() - 1) + '\n' +
            'Adjunto el Excel con TODOS los participantes.',
      attachments: [blob]
    });
  } catch (err) {
    console.error('No se pudo enviar el correo: ' + err);
  }

  return ContentService.createTextOutput('ok');
}

function doGet() { return ContentService.createTextOutput('LUDSTORE activo'); }

// Ejecuta esta función UNA vez (botón ▶) para aceptar los permisos de Google
function autorizar() {
  DriveApp.getRootFolder();
  MailApp.getRemainingDailyQuota();
  UrlFetchApp.fetch('https://www.google.com');
}
