// CORPORACIÓN LUDSTORE - JavaScript

// ===== MENÚ MÓVIL =====
function toggleMenu() {
    document.getElementById('navMenu').classList.toggle('active');
}

// ===== ALERTAS / FLASH =====
function showAlert(message, type = 'success') {
    const container = document.getElementById('flashContainer') || createFlashContainer();
    const alert = document.createElement('div');
    alert.className = `flash flash-${type}`;
    const icons = { success: 'check-circle', danger: 'exclamation-circle', warning: 'exclamation-triangle', info: 'info-circle' };
    alert.innerHTML = `
        <i class="fas fa-${icons[type] || 'info-circle'}"></i>
        ${message}
        <button onclick="this.parentElement.remove()" class="flash-close">&times;</button>
    `;
    container.appendChild(alert);
    setTimeout(() => {
        alert.style.opacity = '0';
        alert.style.transform = 'translateX(100%)';
        setTimeout(() => alert.remove(), 300);
    }, 5000);
}

function createFlashContainer() {
    const div = document.createElement('div');
    div.id = 'flashContainer';
    div.className = 'flash-container';
    document.body.appendChild(div);
    return div;
}

// ===== LOCALSTORAGE - DATOS DE EJEMPLO =====
function initData() {
    if (!localStorage.getItem('ludstore_init')) {
        // Trabajadores de ejemplo
        const trabajadores = [
            { id: 1, nombres: 'Carlos', apellidos: 'Mendoza López', email: 'carlos@email.com', telefono: '+51 999 111 222', dni: '45678912', ubicacion: 'Arequipa', rubro: 'Operaciones', especialidad: 'Operador de Volquete', experiencia_anos: 5, nivel_estudios: 'Técnico', certificaciones: 'Operador de maquinaria pesada, Seguridad minera', habilidades: 'Conducción de volquetes, Supervisión de equipos, Mantenimiento básico', sobre_mi: 'Profesional con 5 años de experiencia en operaciones mineras a cielo abierto. Especializado en conducción de volquetes de gran tonelaje.', disponible: true, fecha_registro: '2024-01-15' },
            { id: 2, nombres: 'María Elena', apellidos: 'Quispe Huamán', email: 'maria@email.com', telefono: '+51 999 333 444', dni: '47891234', ubicacion: 'Cajamarca', rubro: 'Geología', especialidad: 'Geóloga de Mina', experiencia_anos: 8, nivel_estudios: 'Universitario', certificaciones: 'Geología estructural, Mapeo geológico, SIG', habilidades: 'AutoCAD, ArcGIS, Mapeo geológico, Análisis de rocas', sobre_mi: 'Geóloga con 8 años de experiencia en exploración y mapeo de yacimientos mineros. Experta en SIG y modelado geológico.', disponible: true, fecha_registro: '2024-02-20' },
            { id: 3, nombres: 'Jorge Luis', apellidos: 'Vargas Torres', email: 'jorge@email.com', telefono: '+51 999 555 666', dni: '41234567', ubicacion: 'Lima', rubro: 'Mantenimiento', especialidad: 'Mecánico de Equipos Pesados', experiencia_anos: 12, nivel_estudios: 'Técnico', certificaciones: 'Mecánica diesel, Hidráulica industrial, Soldadura', habilidades: 'Reparación de motores diesel, Sistemas hidráulicos, Diagnóstico electrónico', sobre_mi: 'Mecánico con 12 años de experiencia en mantenimiento de equipos mineros. Especialista en sistemas hidráulicos y motores diesel.', disponible: true, fecha_registro: '2024-03-10' },
            { id: 4, nombres: 'Ana Patricia', apellidos: 'Rojas Díaz', email: 'ana@email.com', telefono: '+51 999 777 888', dni: '48912345', ubicacion: 'Arequipa', rubro: 'Seguridad', especialidad: 'Supervisora de Seguridad', experiencia_anos: 6, nivel_estudios: 'Universitario', certificaciones: 'OSHA, Gestión de riesgos, Primeros auxilios', habilidades: 'Gestión de riesgos, Auditorías de seguridad, Capacitación, Análisis de incidentes', sobre_mi: 'Supervisora de seguridad con 6 años de experiencia en operaciones mineras. Certificada en OSHA y gestión de riesgos.', disponible: true, fecha_registro: '2024-04-05' },
            { id: 5, nombres: 'Luis Alberto', apellidos: 'Castro Pérez', email: 'luis@email.com', telefono: '+51 999 999 000', dni: '42345678', ubicacion: 'Cusco', rubro: 'Perforación', especialidad: 'Perforista de Superficie', experiencia_anos: 9, nivel_estudios: 'Técnico', certificaciones: 'Operación de perforadoras, Control de polvo, Manejo de explosivos', habilidades: 'Perforación diamantina, Control de voladura, Mantenimiento de equipos', sobre_mi: 'Perforista con 9 años de experiencia en perforación de superficie y control de voladura. Experto en equipos Atlas Copco.', disponible: true, fecha_registro: '2024-05-12' },
            { id: 6, nombres: 'Diana', apellidos: 'Flores Sánchez', email: 'diana@email.com', telefono: '+51 999 222 333', dni: '46789123', ubicacion: 'Lima', rubro: 'Ingeniería', especialidad: 'Ingeniera de Minas', experiencia_anos: 7, nivel_estudios: 'Universitario', certificaciones: 'Ingeniería de minas, Planificación minera, Software minero', habilidades: 'MineSight, Vulcan, Planificación de producción, Optimización de recursos', sobre_mi: 'Ingeniera de minas con 7 años de experiencia en planificación y optimización de recursos. Experta en software minero.', disponible: true, fecha_registro: '2024-06-01' }
        ];

        // Empresas de ejemplo
        const empresas = [
            { id: 1, nombre: 'Minera Las Bambas S.A.', ruc: '20100012345', email: 'rrhh@lasbambas.com', telefono: '+51 1 234 5678', sector: 'Minería de Cobre', descripcion: 'Una de las minas de cobre más grandes del mundo, ubicada en la región de Apurímac. Comprometidos con el desarrollo sostenible y la seguridad.', ubicacion: 'Apurímac, Perú', vacantes: 3 },
            { id: 2, nombre: 'Southern Copper Corporation', ruc: '20100067890', email: 'talento@southerncopper.com', telefono: '+51 1 987 6543', sector: 'Minería de Cobre', descripcion: 'Empresa líder en la producción de cobre con operaciones en Perú y México. Buscamos talento comprometido con la excelencia.', ubicacion: 'Lima / Moquegua', vacantes: 5 },
            { id: 3, nombre: 'Compañía Minera Antamina', ruc: '20100011122', email: 'empleo@antamina.com', telefono: '+51 1 456 7890', sector: 'Minería de Zinc', descripcion: 'Mayor productor mundial de zinc y plata. Operamos en la Cordillera de los Andes con los más altos estándares de seguridad.', ubicacion: 'Ancash, Perú', vacantes: 2 }
        ];

        // Vacantes de ejemplo
        const vacantes = [
            { id: 1, titulo: 'Operador de Volquete 793F', descripcion: 'Buscamos operadores de volquete Caterpillar 793F con experiencia en minas a cielo abierto. Turnos rotativos de 14x7.', rubro: 'Operaciones', ubicacion: 'Apurímac', salario: 'S/ 4,500 - S/ 6,000', tipo_contrato: 'Tiempo Completo', requisitos: '3+ años de experiencia, Licencia de conducir vigente, Certificación de operador', beneficios: 'Seguro médico, alimentación, transporte, bonos de producción', fecha_publicacion: '2024-07-20', activa: true, empresa_id: 1, empresa_nombre: 'Minera Las Bambas S.A.' },
            { id: 2, titulo: 'Geólogo de Mina Senior', descripcion: 'Se requiere geólogo para mapeo geológico y control de calidad de mineral. Experiencia en yacimientos porfíricos.', rubro: 'Geología', ubicacion: 'Moquegua', salario: 'S/ 8,000 - S/ 12,000', tipo_contrato: 'Indefinido', requisitos: 'Título universitario en Geología, 5+ años de experiencia, Dominio de ArcGIS', beneficios: 'Seguro de vida, plan de carrera, capacitaciones internacionales', fecha_publicacion: '2024-07-25', activa: true, empresa_id: 2, empresa_nombre: 'Southern Copper Corporation' },
            { id: 3, titulo: 'Mecánico de Equipos Pesados', descripcion: 'Mecánico para mantenimiento preventivo y correctivo de palas eléctricas y camiones de gran tonelaje.', rubro: 'Mantenimiento', ubicacion: 'Ancash', salario: 'S/ 5,000 - S/ 7,500', tipo_contrato: 'Tiempo Completo', requisitos: 'Título técnico en Mecánica, 4+ años en equipos mineros, Conocimiento en sistemas hidráulicos', beneficios: 'Vivienda campamento, alimentación, transporte, utilidades', fecha_publicacion: '2024-07-28', activa: true, empresa_id: 3, empresa_nombre: 'Compañía Minera Antamina' },
            { id: 4, titulo: 'Supervisor de Seguridad', descripcion: 'Supervisor para implementar y monitorear programas de seguridad en operaciones mineras subterráneas.', rubro: 'Seguridad', ubicacion: 'Apurímac', salario: 'S/ 6,000 - S/ 8,500', tipo_contrato: 'Indefinido', requisitos: 'Título universitario, Certificación OSHA, 5+ años de experiencia', beneficios: 'Seguro médico familiar, bonos trimestrales, capacitaciones', fecha_publicacion: '2024-07-29', activa: true, empresa_id: 1, empresa_nombre: 'Minera Las Bambas S.A.' },
            { id: 5, titulo: 'Perforista de Superficie', descripcion: 'Operador de perforadoras de superficie para exploración y producción. Experiencia en equipos Atlas Copco y Sandvik.', rubro: 'Perforación', ubicacion: 'Moquegua', salario: 'S/ 4,000 - S/ 5,500', tipo_contrato: 'Tiempo Completo', requisitos: 'Certificación de perforista, 3+ años de experiencia, Disponibilidad para turnos', beneficios: 'Campamento, alimentación, transporte, seguro de accidentes', fecha_publicacion: '2024-07-30', activa: true, empresa_id: 2, empresa_nombre: 'Southern Copper Corporation' }
        ];

        localStorage.setItem('trabajadores', JSON.stringify(trabajadores));
        localStorage.setItem('empresas', JSON.stringify(empresas));
        localStorage.setItem('vacantes', JSON.stringify(vacantes));
        localStorage.setItem('ludstore_init', 'true');
    }
}

// ===== FUNCIONES DE DATOS =====
function getTrabajadores() {
    return JSON.parse(localStorage.getItem('trabajadores') || '[]');
}

function getEmpresas() {
    return JSON.parse(localStorage.getItem('empresas') || '[]');
}

function getVacantes() {
    return JSON.parse(localStorage.getItem('vacantes') || '[]');
}

function addTrabajador(trabajador) {
    const data = getTrabajadores();
    trabajador.id = Date.now();
    trabajador.fecha_registro = new Date().toISOString().split('T')[0];
    trabajador.disponible = true;
    data.push(trabajador);
    localStorage.setItem('trabajadores', JSON.stringify(data));
    return trabajador;
}

function addEmpresa(empresa) {
    const data = getEmpresas();
    empresa.id = Date.now();
    empresa.vacantes = 0;
    data.push(empresa);
    localStorage.setItem('empresas', JSON.stringify(data));
    return empresa;
}

function addVacante(vacante) {
    const data = getVacantes();
    vacante.id = Date.now();
    vacante.fecha_publicacion = new Date().toISOString().split('T')[0];
    vacante.activa = true;
    data.push(vacante);
    localStorage.setItem('vacantes', JSON.stringify(data));
    return vacante;
}

function deleteVacante(id) {
    let data = getVacantes();
    data = data.filter(v => v.id != id);
    localStorage.setItem('vacantes', JSON.stringify(data));
}

// ===== SESIÓN =====
function loginUser(email, tipo) {
    if (tipo === 'empresa') {
        const empresas = getEmpresas();
        const empresa = empresas.find(e => e.email === email);
        if (empresa) {
            localStorage.setItem('currentUser', JSON.stringify({ ...empresa, tipo: 'empresa' }));
            return true;
        }
    } else {
        const trabajadores = getTrabajadores();
        const trabajador = trabajadores.find(t => t.email === email);
        if (trabajador) {
            localStorage.setItem('currentUser', JSON.stringify({ ...trabajador, tipo: 'trabajador' }));
            return true;
        }
    }
    return false;
}

function logoutUser() {
    localStorage.removeItem('currentUser');
}

function getCurrentUser() {
    return JSON.parse(localStorage.getItem('currentUser') || 'null');
}

function isLoggedIn() {
    return getCurrentUser() !== null;
}

// ===== INICIALIZAR =====
document.addEventListener('DOMContentLoaded', function() {
    initData();
    updateNavbar();
});

function updateNavbar() {
    const user = getCurrentUser();
    const navMenu = document.getElementById('navMenu');
    if (!navMenu) return;

    const loginLink = navMenu.querySelector('.btn-nav-login');
    if (loginLink && user) {
        loginLink.outerHTML = `
            <a href="panel-empresa.html" class="btn-nav-login"><i class="fas fa-user"></i> ${user.nombre || user.nombres}</a>
            <a href="#" onclick="logout(); return false;" class="btn-nav-logout"><i class="fas fa-sign-out-alt"></i> Salir</a>
        `;
    }
}

function logout() {
    logoutUser();
    showAlert('Sesión cerrada correctamente', 'info');
    setTimeout(() => window.location.href = 'index.html', 1000);
}
